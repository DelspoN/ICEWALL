docker build -t php-practice .
