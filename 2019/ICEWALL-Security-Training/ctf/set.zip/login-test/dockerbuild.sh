docker build -t login-test .
